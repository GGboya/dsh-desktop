/** Locale bundles for the built-in plugins settings section. */
/** Locale keys the section renders. */
export type PluginsSettingsLocaleKey = 'nav' | 'title' | 'intro' | 'tabs' | 'empty';
/** English copy. */
export declare const en: Record<PluginsSettingsLocaleKey, string>;
/** Simplified Chinese copy. */
export declare const zh: Record<PluginsSettingsLocaleKey, string>;
//# sourceMappingURL=locales.d.ts.map