/**
 * Agent-scoped durable one-shot and fixed-rate reminders over the session event log.
 * @module @deepseek-ai/dsh-schedule
 */
import type { Context } from '@deepseek-ai/cordis';
export type * from './types.ts';
export { SCHEDULE_CHANGE_VERSION, MIN_EVERY_INTERVAL_SECONDS, ScheduleId, ScheduleInputError, ScheduleLogError, allocateScheduleId, createAfterScheduleRecord, createAtScheduleRecord, createEveryScheduleRecord, decodeScheduleChange, foldScheduleEvents, renderReminderFraming, renderEveryReminderBatchFraming, resolveEveryOccurrence, scheduleView, } from './domain.ts';
export { registerScheduleTools } from './tools.ts';
/** Cordis function-plugin name. */
export declare const name = "schedule";
/** Services required before future root agents can receive Schedule. */
export declare const inject: string[];
/**
 * Install Schedule only for root agents published after this plugin loads,
 * and answer the Workspace registry's archive admission for every session
 * this plugin owns a runtime for. The owner answers from its own fold of the
 * live log, so a session without a live agent or without an owned runtime
 * — nothing armed that could fire — reports nothing and has nothing to stop.
 * Active reminders count as activity. A stop request is a management delete
 * in the agent's transaction queue, serialized with the tools and the
 * owner's due transaction: it awaits the shared persistence barrier before
 * reading the fold, appends the same durable `schedule/change` delete the
 * `schedule_delete` tool records for every active reminder, and awaits a
 * second barrier after the appends. A failed barrier rejects the stop, which
 * the registry logs, leaving the reminders for the archived-session gate to
 * block when they fire.
 */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map