import type { SessionId } from '@deepseek-ai/dsh-session/types';
import type { TeamMemberView as TeamRosterMember, TeamView } from '@deepseek-ai/dsh-experimental-agent-team/client';
import type { RemoteResult } from '@deepseek-ai/dsh-api-remotes/client';
import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import { NS } from './locales.ts';
/** Generated Remote result consumed directly by the Team UI. */
export type TeamActionResult<T> = RemoteResult<T>;
/** Business actions injected by the browser plugin. */
export interface TeamActionInjected {
    load: (sessionId: SessionId) => Promise<TeamActionResult<TeamView>>;
    openTeammate: (sessionId: SessionId, member: TeamRosterMember) => void;
}
/** Full props of the Team conversation-header action. */
export type TeamActionProps = PropsRuntime<'conversation.session.header.actions'> & TeamActionInjected & PropsLocale<typeof NS>;
/** Render the Team roster and read-only task board. */
export declare function TeamAction({ sessionId, load, openTeammate, t, }: TeamActionProps): import("react").JSX.Element;
//# sourceMappingURL=TeamAction.d.ts.map