import type { ObservableSnapshot } from '@deepseek-ai/dsh-client-store';
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import { NS } from './locales.ts';
/** Browser operations and state injected into the Session Header contribution. */
export interface OpenInAppActionInjected {
    hooks: {
        openInAppApps: ObservableSnapshot<readonly string[] | null>;
        openInAppChoice: ObservableSnapshot<string>;
    };
    launch: (appId: string, path: string) => Promise<void>;
    choose: (appId: string) => void;
    iconUrl: (appId: string) => string;
}
/** Full props for the Session-header open-in-app split button. */
export type OpenInAppActionProps = PropsRuntime<'conversation.session.header.utilities'> & PropsLocale<typeof NS> & InjectFace<OpenInAppActionInjected>;
/**
 * Adapt the installed directory catalog to the shared opening control.
 * @param props - workspace state, installed catalog, and launch operations.
 * @returns the shared control, or null without an eligible application and directory.
 */
export declare function OpenInAppAction(props: OpenInAppActionProps): React.JSX.Element | null;
//# sourceMappingURL=OpenInAppAction.d.ts.map