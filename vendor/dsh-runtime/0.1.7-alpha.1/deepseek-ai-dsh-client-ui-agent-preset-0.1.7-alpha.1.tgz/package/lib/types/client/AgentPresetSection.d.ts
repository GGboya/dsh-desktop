import type { ObservableSnapshot, SnapshotStore } from '@deepseek-ai/dsh-client-store';
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { AgentPresetSectionState } from './section-store.ts';
/** Settings actions and their shared controller state. */
export interface AgentPresetSectionInjected {
    hooks: {
        agentPresetSection: SnapshotStore<AgentPresetSectionState>;
        /** Shared preference controlling the picker-policy row. */
        developerTools: ObservableSnapshot<boolean>;
    };
    /** Stage the `cordis` preset and start a Creator-mode task; absent without a conversation flow. */
    startCreatorDraft?: () => void;
    load: () => Promise<void>;
    makeDefault: (id: string) => Promise<void>;
    setPickerVisible: (visible: boolean) => Promise<void>;
}
/** Props assembled by the settings renderer. */
export type AgentPresetSectionProps = PropsRuntime<'settings.section'> & PropsLocale<'settings.agentPreset'> & InjectFace<AgentPresetSectionInjected>;
/** Render the roster with its default, mode help, and the guidance to Creator mode.
 * @param props Settings actions, snapshot hooks and localized text.
 * @returns The preset settings section.
 */
export declare function AgentPresetSection({ useAgentPresetSection, load, makeDefault, setPickerVisible, startCreatorDraft, close: closeSettings, useDeveloperTools, t, }: AgentPresetSectionProps): import("react").JSX.Element;
//# sourceMappingURL=AgentPresetSection.d.ts.map