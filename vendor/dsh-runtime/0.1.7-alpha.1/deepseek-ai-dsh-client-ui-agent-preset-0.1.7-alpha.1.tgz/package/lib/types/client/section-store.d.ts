/** Preset roster and selection policy for the settings section. */
import type { Context } from '@deepseek-ai/cordis';
import { type SnapshotStore } from '@deepseek-ai/dsh-client-store';
import type { AgentPresetRow } from '@deepseek-ai/dsh-agent-preset-registry/types';
/** Settings page state. */
export interface AgentPresetSectionState {
    status: 'idle' | 'loading' | 'ready' | 'error';
    error: string | null;
    showPicker: boolean;
    policySaving: boolean;
    rows: readonly AgentPresetRow[];
}
/** Loads the roster and writes the default and chooser policy. */
export declare class AgentPresetSectionController {
    private readonly ctx;
    /** Observable roster and selection state. */
    readonly store: SnapshotStore<AgentPresetSectionState>;
    private loading;
    constructor(ctx: Context);
    private set;
    /** Refresh the roster; concurrent calls share one read.
     * @returns Once the roster read settles.
     */
    load(): Promise<void>;
    private readRoster;
    /** Set the default and synchronize the current blank task when supplied.
     * @param id Selected default.
     * @param sync Blank-session synchronization callback.
     * @returns Once saved and refreshed.
     */
    makeDefault(id: string, sync?: (id: string) => Promise<string | undefined>): Promise<void>;
    /** Change chooser visibility.
     * @param visible Whether the chooser is visible.
     * @param sync Blank-session synchronization callback.
     * @returns Once saved and refreshed.
     */
    setPickerVisible(visible: boolean, sync?: (id: string) => Promise<string | undefined>): Promise<void>;
    private policy;
}
//# sourceMappingURL=section-store.d.ts.map