/** Authenticated Remote operations for account UI consumers. */
import { Context } from '@deepseek-ai/cordis';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import type { AccountDetails } from '@deepseek-ai/dsh-deepseek-account/types';
import type { AccountView, SignInAttemptId } from './types.ts';
/** Account commands and reconnect-safe state stream. */
export declare class AccountController extends TypertRemoteService {
    static inject: string[];
    /** @param ctx - Host with the account provider mounted. */
    constructor(ctx: Context);
    /**
     * Read the safe account projection.
     * @returns current account and attempt state.
     */
    getState(): Promise<AccountView>;
    /**
     * Query display-safe Platform profile data.
     * @returns profile outcome, or null when the account grant is absent or changed.
     */
    getProfile(): Promise<AccountDetails['profile'] | null>;
    /**
     * Query Platform recharge-wallet balances.
     * @returns balance outcome, or null when the account grant is absent or changed.
     */
    getBalance(): Promise<AccountDetails['balance'] | null>;
    /**
     * Begin browser sign-in.
     * @param locale - active UI language for a new attempt.
     * @param callbackOrigin - browser-accessible loopback HTTP origin.
     * @param loginSource - initiating UI, used to return from a failed exchange.
     * @returns a new or already-active login attempt.
     */
    startSignIn(locale: string, callbackOrigin: string, loginSource: 'web' | 'desktop'): Promise<AccountView>;
    /**
     * Cancel the named local attempt.
     * @param attemptId - attempt to cancel.
     * @returns settled cancellation or commit state.
     */
    cancelSignIn(attemptId: SignInAttemptId): Promise<AccountView>;
    /**
     * Remove the local account grant and revoke it through Platform in the background, without deleting API keys.
     * @returns state after removing the local account grant.
     */
    signOut(): Promise<AccountView>;
    /**
     * Stream the safe account projection.
     * @param signal - stream lifetime.
     * @returns initial snapshot and subsequent changes.
     */
    watch(signal: AbortSignal): AsyncIterable<AccountView>;
}
export default AccountController;
//# sourceMappingURL=index.d.ts.map