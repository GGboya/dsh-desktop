/** Static Browser tab type and guide declaration. */
import type { TranslateNS } from '@deepseek-ai/dsh-client-locale/client';
import type { SidebarRightTabDefinition } from '@deepseek-ai/dsh-client-ui-sidebar-right/client';
/** Browser tab kind. */
export declare const BROWSER_KIND = "browser";
/** Browser implementation identity and keyed Slot dispatch key. */
export declare const BROWSER_ID = "@deepseek-ai/dsh-client-ui-sidebar-browser";
/** Build the Browser type with locale-live copy. */
export declare function browserDefinition(t: TranslateNS<'sidebarBrowser'>): SidebarRightTabDefinition;
//# sourceMappingURL=definition.d.ts.map