/** Feishu questionnaire context follows the Platform Web ticket fields. */
import type { Config } from '../contact-config.ts';
import type { AccountProfile } from '@deepseek-ai/dsh-deepseek-account/types';
/**
 * Build an external questionnaire URL without authentication credentials.
 * @param config - questionnaire destination and supported source option.
 * @param context - currently available account and browser environment.
 * @returns questionnaire URL with hidden, optionally prefilled context fields.
 */
export declare function contactUrl(config: Config, context: {
    uid: AccountProfile['id'];
    version: string | undefined;
    locale: string;
    width: number;
    height: number;
    pixelRatio: number;
}): string;
//# sourceMappingURL=contact-url.d.ts.map