import { Context, Service, type Fiber } from '@deepseek-ai/cordis';
import { type RedactedSecret } from './redact.ts';
import type { SettingsNamespace } from './types.ts';
export { redactSecrets } from './redact.ts';
export type { RedactedSecret, RedactedValue } from './redact.ts';
export type { SettingsNamespace } from './types.ts';
/** One Loader entry's live Config fields. */
export interface SettingsDescriptor {
    ns: SettingsNamespace;
    /** Whether the UI may generate a page when no custom page exists. */
    autoGenerate: boolean;
    schema: unknown;
    value: unknown;
    revision: number;
    base?: unknown;
    user?: unknown;
    applies: 'live';
    secrets?: RedactedSecret[];
}
/** Wire readers always request secret redaction. */
export interface SettingsDescribeOptions {
    redactSecrets?: boolean;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** Schema-derived plugin configuration forms. */
        settings: SettingsForms;
    }
}
/** Refusal to overwrite configuration changed since the form was read. */
export declare class SettingsConflictError extends Error {
    /** Stable machine code for wire layers mapping this to their own taxonomy. */
    readonly code = "SETTINGS_CONFLICT";
    /** The revision the write expected. */
    readonly expected: number;
    /** The revision the namespace actually stands at. */
    readonly actual: number;
    /**
     * @param ns - the namespace whose write was refused.
     * @param expected - the revision the caller sent.
     * @param actual - the revision now stored.
     */
    constructor(ns: SettingsNamespace, expected: number, actual: number);
}
/**
 * One path-addressed edit to a namespace's user section. Path mutation exists
 * for a caller holding an INCOMPLETE view of the section — a configuration UI
 * reads the redacted descriptor, which by construction never received the
 * `role('secret')` fields. Such a caller can name the field it means without
 * restating the section: a wholesale `replace` rebuilt from a redacted
 * document silently deletes every secret the wire never returned.
 */
export type SettingsPathOp = {
    op: 'set';
    path: readonly string[];
    value: unknown;
} | {
    op: 'unset';
    path: readonly string[];
};
/** Project Config schemas into forms and own optional instance-level UI policy. */
export declare class SettingsForms extends Service {
    private readonly ownerContext;
    static inject: string[];
    private revisions;
    private closed;
    private scheduled;
    private readonly presentations;
    constructor(ownerContext: Context);
    /** Move the sections of the removed `settings.yaml` into the active profile once the Loader has settled every entry.
     * The document is renamed before the first write, so a partial import never repeats; a section the running
     * composition rejects is logged and remains only in the renamed file. */
    private importLegacyDocument;
    /** Register the calling plugin instance's page policy without changing its Config.
     * @param presentation Automatic-page policy for this instance; `auto` defaults to true.
     * @param owner Plugin instance the policy belongs to; defaults to the calling fiber.
     * @returns Disposer; register it with the calling plugin's effects.
     * @throws If this instance already has a registered policy.
     */
    configure(presentation: {
        auto?: boolean;
    }, owner?: Fiber): () => void;
    private invalidate;
    /** Whether the active profile accepts form edits. */
    get writable(): boolean;
    /** Current profile patch shown by the native configuration editor. */
    get documentPath(): string;
    /** Locate the profile patch for native editing.
     * @returns The existing profile patch path.
     */
    prepareDocument(): Promise<string>;
    /** Read active plugin schemas and their live values.
     * @param options Redaction required for remote callers.
     * @returns Forms keyed by unique profile entry ids.
     */
    describe(options?: SettingsDescribeOptions): SettingsDescriptor[];
    /** Merge editable fields into an entry's config.
     * @param ns Profile entry id.
     * @param patch Fields to merge.
     * @param expectedRevision Revision returned by describe.
     */
    update(ns: string, patch: object, expectedRevision?: number): Promise<void>;
    /** Reset all live fields, then set the supplied fields; ordinary config is preserved.
     * @param ns Profile entry id.
     * @param section Complete form values.
     * @param expectedRevision Revision returned by describe.
     */
    replace(ns: string, section: object, expectedRevision?: number): Promise<void>;
    /** Apply field edits without restating redacted secrets; unsetting an array index removes its element.
     * @param ns Profile entry id.
     * @param ops Ordered form edits.
     * @param expectedRevision Revision returned by describe.
     */
    mutate(ns: string, ops: readonly SettingsPathOp[], expectedRevision?: number): Promise<void>;
    private write;
    private schema;
}
export default SettingsForms;
//# sourceMappingURL=index.d.ts.map