/**
 * The preview's asynchronous half: reading pages into the store.
 *
 * The component never awaits anything. It asks for a page and this face performs
 * the read and writes the outcome through the store's own actions — the
 * Slot-standard `inject` form, so the write set stays the store's. The session
 * the read runs under comes from the file's address, not from the slot's
 * session: the address is the read's whole authority.
 *
 * A tab's pages are one file version walked from the first line. Dropping them
 * — a reload, or a page of a newer version arriving past the first line, which
 * restarts the walk — retires every read still in flight for the tab: a
 * settlement from before the drop writes nothing. Cleanup rides the owner's
 * `signal`, armed once per tab by its first read: the abort forgets the tab's
 * bucket and this bookkeeping, a request is not made for a record that already
 * ended, and a settlement arriving after the record is gone has nothing left to
 * write to. A tab that never read has no bucket to forget.
 */
import type { BoundActions } from '@deepseek-ai/dsh-client-store';
import type { TabId } from '@deepseek-ai/dsh-client-ui-dockkit';
import type { SessionId } from '@deepseek-ai/dsh-session/types';
import type { ReadDocumentBytes, ReadWorkspaceFilePage, SessionFile } from './rpc.ts';
import type { TextStore } from './store.ts';
import type { Resources } from '@deepseek-ai/dsh-client-resources/client';
/** The preview's injected business face, as the body receives it. */
export interface TextInjected {
    /** Observe one renderer dependency. @param tabId - owning tab. @param address - resource address. @param signal - tab lifetime. */
    readonly addResource: (tabId: TabId, address: string, signal: AbortSignal) => void;
    /** Replace dependency membership. @param tabId - owning tab. @param addresses - resource addresses. @param signal - tab lifetime. */
    readonly setResources: (tabId: TabId, addresses: readonly string[], signal: AbortSignal) => void;
    /**
     * Read one page into the store. A page of a newer file version than the pages
     * held, arriving past the first line, is not kept: the tab's pages are dropped
     * and the first page read again. The tab's first read arms the abort listener
     * that forgets its bucket when the record ends.
     * @param tabId - the tab being drawn.
     * @param file - the session and workspace path the tab's address names.
     * @param offset - 1-based line the page starts at.
     * @param signal - the tab record's lifetime.
     * @param observedVersion - metadata version observed at read start.
     */
    readonly loadPage: (tabId: TabId, file: SessionFile, offset: number, signal: AbortSignal, observedVersion?: string) => void;
    /**
     * Drop every page and read the first one again, for a file the Host reports
     * changed. The view is kept, so the reader stays where they were; a page read
     * still in flight writes nothing when it settles.
     * @param tabId - the tab being drawn.
     * @param file - the session and workspace path the tab's address names.
     * @param signal - the tab record's lifetime.
     * @param observedVersion - metadata version observed at read start.
     */
    readonly reloadPages: (tabId: TabId, file: SessionFile, signal: AbortSignal, observedVersion?: string) => void;
    /**
     * Read the complete file for a whole-file renderer.
     * @param tabId - owning tab.
     * @param file - the session and workspace path the tab's address names.
     * @param signal - tab lifetime.
     * @param observedVersion - metadata version observed at read start.
     */
    readonly loadAll: (tabId: TabId, file: SessionFile, signal: AbortSignal, observedVersion?: string) => void;
    /**
     * Discard the old complete result and read again.
     * @param tabId - owning tab.
     * @param file - the session and workspace path the tab's address names.
     * @param signal - tab lifetime.
     * @param observedVersion - metadata version observed at read start.
     */
    readonly reloadAll: (tabId: TabId, file: SessionFile, signal: AbortSignal, observedVersion?: string) => void;
    /**
     * Begin a renderer-owned load without reading source bytes.
     * @param tabId - owning tab.
     * @param signal - tab lifetime.
     * @param rendererId - selected implementation.
     * @param observedVersion - metadata version observed at request start.
     * @param reload - discard the previous content revision.
     */
    readonly prepareRenderer: (tabId: TabId, signal: AbortSignal, rendererId: string, observedVersion?: string, reload?: boolean) => void;
}
/**
 * Bind the preview's face to one paged read and one complete-byte read.
 * @param read - the bound `workspaceFiles.read` call.
 * @param readAll - complete-byte workspace Remote read.
 * @param resources - shared metadata sources for the document and its dependencies.
 * @returns the Slot `inject` factory: bound actions in, face out. The slot's session id is unused because the address carries its own.
 */
export declare function textFace(read: ReadWorkspaceFilePage, readAll: ReadDocumentBytes, resources: Resources): (sessionId: SessionId, actions: BoundActions<TextStore>) => TextInjected;
//# sourceMappingURL=face.d.ts.map