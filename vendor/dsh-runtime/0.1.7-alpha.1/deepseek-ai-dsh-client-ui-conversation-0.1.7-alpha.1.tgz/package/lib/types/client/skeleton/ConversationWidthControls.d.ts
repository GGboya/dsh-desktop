import type { ConversationWidthControlsProps } from '../contract/slots.ts';
/**
 * Install the main Conversation width axis and render its drag handles.
 * @param props - Mounted Conversation body and current presentation phase.
 * @returns two active-phase width handles, or no controls outside the active phase.
 */
export declare function ConversationWidthControls({ container, phase }: ConversationWidthControlsProps): import("react").JSX.Element[] | null;
//# sourceMappingURL=ConversationWidthControls.d.ts.map