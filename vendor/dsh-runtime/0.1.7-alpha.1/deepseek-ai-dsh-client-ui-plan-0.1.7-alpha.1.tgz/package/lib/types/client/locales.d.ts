/** `plan` namespace dictionaries (the composer plan chip's copy). */
/** Simplified Chinese dictionary (the key-set source of truth). */
export declare const zh: {
    'chip.label': string;
    'preview.title': string;
    'preview.document': string;
    'preview.action': string;
    'preview.open': string;
    'preview.full': string;
    'preview.openNamed': string;
    'preview.loading': string;
    'preview.failed': string;
    'preview.invalidAddress': string;
    'preview.historyUnavailable': string;
    'preview.notFound': string;
    'preview.unavailable': string;
    'preview.expired': string;
    'chip.on.aria': string;
    'chip.on.title': string;
    'chip.exitFailed': string;
};
/** The plan namespace key union. */
export type PlanKey = keyof typeof zh;
/** English dictionary, checked complete against the zh key set. */
export declare const en: {
    'chip.label': string;
    'preview.title': string;
    'preview.document': string;
    'preview.action': string;
    'preview.open': string;
    'preview.full': string;
    'preview.openNamed': string;
    'preview.loading': string;
    'preview.failed': string;
    'preview.invalidAddress': string;
    'preview.historyUnavailable': string;
    'preview.notFound': string;
    'preview.unavailable': string;
    'preview.expired': string;
    'chip.on.aria': string;
    'chip.on.title': string;
    'chip.exitFailed': string;
};
//# sourceMappingURL=locales.d.ts.map