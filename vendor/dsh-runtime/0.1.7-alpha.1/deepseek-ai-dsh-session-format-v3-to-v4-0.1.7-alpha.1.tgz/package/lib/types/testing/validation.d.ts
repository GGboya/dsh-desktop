import type { SessionFormatArtifact } from '@deepseek-ai/dsh-session-format';
/**
 * Validate an artifact through the native codec without vocabulary-aware restoration.
 * @param artifact - current-generation artifact to encode and decode.
 */
export declare function assertReleasedV4Artifact(artifact: SessionFormatArtifact): void;
//# sourceMappingURL=validation.d.ts.map